<?php

include 'koneksi.php';

$nama= $_POST['nama'];
$email= $_POST['email'];
$no_telpon= $_POST['no_telpon'];
$pekerjaan= $_POST['pekerjaan'];




 mysqli_query($dbconnect, "INSERT INTO kontak VALUES ( NULL , '$nama','$email','$no_telpon','$pekerjaan')");

 header("location:user.php")
 ?>

 