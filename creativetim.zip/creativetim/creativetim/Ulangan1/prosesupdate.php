<?php

include 'koneksi.php';
$id = $_POST['id'];
$nama= $_POST['nama'];
$email= $_POST['email'];
$no_telpon = $_POST['no_telpon'];
$pekerjaan = $_POST['pekerjaan'];



 mysqli_query($dbconnect, "UPDATE `kontak` SET `nama` = '$nama', `email` = '$email', `no_telpon` = '$no_telpon', `pekerjaan` = '$pekerjaan' WHERE `kontak`.`id` = '$id' ");
  header("location:user.php");
  ?>




