<!doctype html>
<html lang="en">

<head>
  <title>Hello, world!</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Material Kit CSS -->
  <link href="assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
</head>

<body class="dark-edition">
  <div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="black" data-image="./assets/img/sidebar-2.jpg">
      <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
      <div class="logo">
        <a href="http://www.creative-tim.com" class="simple-text logo-normal">
          Creative Tim
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="javascript:void(0)">
              <i class="material-icons"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item active  ">
            <a class="nav-link" href="javascript:void(0)">
              <i class="material-icons"></i>
              <p>kontak</p>
            </a>
          </li>
          <!-- your sidebar here -->
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:void(0)">Dashboard</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="javascript:void(0)">
                  <i class="material-icons">notifications</i>
                  <p class="d-lg-none d-md-block">
                    Notifications
                  </p>
                </a>
              </li>
              <!-- your navbar here -->
            </ul>
          </div>
        </div>
      </nav>

		<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h2"></h1>
		</div>


		<section>
			

			<form action="prosesupdate.php" method="post">
				
				<?php
				include 'koneksi.php';
				$id=$_GET['id'];
				$query = mysqli_query($dbconnect, "SELECT * FROM kontak WHERE id = '$id' ");

				$tampil = mysqli_fetch_assoc($query);

				?>
		<section>
			<section>
				<section>
					<div class="mb-3">
			<label for="id" class="form-label">Id</label>
			<input type="text"  class="form-control" id="id" name="id" readonly value="<?php echo $tampil ['id']?>">
					</div>
					<div class="mb-3">
			<label for="nama" class="form-label">nama</label>
			<input type="text" class="form-control" id="nama" name="nama" value="<?php echo $tampil ['nama']?>">
					</div>
					<div class="mb-3">
			<label for="email" class="form-label">email</label>
			<input type="text"  class="form-control" id="email" name="email" value="<?php echo $tampil ['email']?>">
					</div>
					<div class="mb-3">
			<label for="no_telpon" class="form-label">no_telpon</label>
			<input type="text"  class="form-control" id="no_telpon" name="no_telpon" value="<?php echo $tampil ['no_telpon']?>">
					</div>
					<div class="mb-3">
			<label for="pekerjaan" class="form-label">pekerjaan</label>
			<input type="number"  class="form-control" id="stok" name="pekerjaan" value="<?php echo $tampil ['pekerjaan']?>">
					</div>
				
					<div class="mb-3">
						<button type="submit" name="inputdata" class="btn btn-primary" onclick="return confirm('apakah ayang yakin ingin mengubah data tersebut?')">Ubah</button>
					</div>
				</section>
			</section>
		</section>
			</form>
		</section>
		</main>
  </div>
</div>

		<script type="text/javascript" src="../assets/js/bootstrap.bundle.min.js"></script>

		<script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="dashboard.js"></script>
 	</body>
 </html>