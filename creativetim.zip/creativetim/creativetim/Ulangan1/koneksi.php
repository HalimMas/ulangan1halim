<?php

$host = "localhost";
$user = "root";
$pass = "";
$db	  = "phpcrud";

$dbconnect = new mysqli("$host","$user","$pass","$db");

?>